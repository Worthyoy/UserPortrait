from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
from datetime import datetime
from math import exp, log1p, sqrt
from statistics import median
from typing import Any

import pandas as pd


REQUIRED_COLUMNS = {"user_id", "action_name", "event_time"}


@dataclass(frozen=True)
class ProfileConfig:
    activity_window_days: int = 30
    high_active_days: int = 15
    high_active_percentile: float = 0.80
    mid_active_days: int = 4
    # Deprecated: retained for compatibility with the former window-based
    # recent-task implementation. Recent tasks now use recent_event_top_k.
    high_recent_window_days: int = 3
    mid_recent_window_days: int = 7
    low_recent_window_days: int = 30
    low_recent_fallback_events: int = 5
    recent_top_k: int = 10
    recent_event_top_k: int = 3
    min_period_occurrences: int = 3
    daily_min_occurrences: int = 5
    daily_min_span_days: int = 5
    weekly_min_occurrences: int = 4
    weekly_min_span_days: int = 21
    monthly_min_months: int = 3
    daily_detection_window_days: int = 7
    weekly_detection_window_days: int = 56
    monthly_detection_window_days: int = 186
    interval_detection_recent_occurrences: int = 6
    strong_period_cv: float = 0.20
    calendar_concentration: float = 0.75
    interval_max_min_ratio: float = 1.25
    min_period_confidence: float = 0.70
    session_gap_minutes: int = 30
    sequence_min_len: int = 2
    sequence_max_len: int = 5
    # Deprecated: the pair/long-sequence thresholds below are authoritative.
    min_sequence_support: int = 2
    min_sequence_confidence: float = 0.50
    min_pair_sequence_support: int = 3
    min_pair_sequence_confidence: float = 0.75
    min_long_sequence_support: int = 2
    min_long_sequence_confidence: float = 0.60
    subsequence_support_margin: int = 2
    sequence_top_k: int = 5
    high_freq_recent_count_7d: int = 4
    high_freq_lift: float = 3.0
    high_freq_recent_concentration: float = 0.60
    frequent_task_top_k: int = 5


def build_user_profiles(
    events: pd.DataFrame,
    *,
    now: str | datetime | pd.Timestamp | None = None,
    config: ProfileConfig | None = None,
) -> dict[str, pd.DataFrame]:
    """Build behavior portrait tables from user_id/action_name/event_time events."""

    cfg = config or ProfileConfig()
    clean_events = _prepare_events(events)
    reference_time = _resolve_now(clean_events, now)
    clean_events = clean_events[clean_events["event_time"] <= reference_time].reset_index(
        drop=True
    )
    if clean_events.empty:
        raise ValueError("events is empty after filtering rows later than now")

    activity = _build_activity_levels(clean_events, reference_time, cfg)
    recent_tasks = _build_recent_tasks(clean_events, activity, reference_time, cfg)
    periodic_tasks = _build_periodic_tasks(clean_events, reference_time, cfg)
    recent_high_freq_tasks = _build_recent_high_freq_tasks(
        clean_events, activity, periodic_tasks, reference_time, cfg
    )
    frequent_tasks = _build_frequent_tasks(clean_events, reference_time, cfg)
    personal_behavior_sequences = _build_behavior_sequences(
        clean_events, reference_time, cfg
    )

    return {
        "activity_levels": activity,
        "recent_tasks": recent_tasks,
        "periodic_tasks": periodic_tasks,
        "recent_high_freq_tasks": recent_high_freq_tasks,
        "frequent_tasks": frequent_tasks,
        "personal_behavior_sequences": personal_behavior_sequences,
    }


def _prepare_events(events: pd.DataFrame) -> pd.DataFrame:
    missing = REQUIRED_COLUMNS - set(events.columns)
    if missing:
        missing_text = ", ".join(sorted(missing))
        raise ValueError(f"missing required columns: {missing_text}")

    df = events.loc[:, ["user_id", "action_name", "event_time"]].copy()
    df["event_time"] = pd.to_datetime(df["event_time"], errors="coerce")
    df = df.dropna(subset=["user_id", "action_name", "event_time"])
    df["user_id"] = df["user_id"].astype(str)
    df["action_name"] = df["action_name"].astype(str)
    df = df.sort_values(["user_id", "event_time", "action_name"]).reset_index(drop=True)
    if df.empty:
        raise ValueError("events is empty after dropping invalid rows")
    return df


def _resolve_now(
    events: pd.DataFrame, now: str | datetime | pd.Timestamp | None
) -> pd.Timestamp:
    if now is None:
        return pd.Timestamp(events["event_time"].max())
    return pd.Timestamp(now)


def _build_activity_levels(
    events: pd.DataFrame, now: pd.Timestamp, cfg: ProfileConfig
) -> pd.DataFrame:
    window_start = now - pd.Timedelta(days=cfg.activity_window_days)
    window_events = events[
        (events["event_time"] > window_start) & (events["event_time"] <= now)
    ].copy()
    window_events["event_date"] = window_events["event_time"].dt.date

    all_users = pd.DataFrame({"user_id": sorted(events["user_id"].unique())})
    stats = (
        window_events.groupby("user_id")
        .agg(event_count_30d=("event_time", "size"), active_days_30d=("event_date", "nunique"))
        .reset_index()
    )
    stats = all_users.merge(stats, on="user_id", how="left").fillna(0)
    stats["event_count_30d"] = stats["event_count_30d"].astype(int)
    stats["active_days_30d"] = stats["active_days_30d"].astype(int)
    active_event_counts = stats.loc[
        stats["event_count_30d"] > 0, "event_count_30d"
    ]
    p80 = (
        float(active_event_counts.quantile(cfg.high_active_percentile))
        if not active_event_counts.empty
        else float("inf")
    )

    def classify(row: pd.Series) -> str:
        if row["event_count_30d"] == 0:
            return "low"
        if row["active_days_30d"] >= cfg.high_active_days or row["event_count_30d"] >= p80:
            return "high"
        if row["active_days_30d"] >= cfg.mid_active_days:
            return "middle"
        return "low"

    stats["user_activity_level"] = stats.apply(classify, axis=1)
    return stats.sort_values("user_id").reset_index(drop=True)


def _recent_window_days(level: str, cfg: ProfileConfig) -> int:
    if level == "high":
        return cfg.high_recent_window_days
    if level == "middle":
        return cfg.mid_recent_window_days
    return cfg.low_recent_window_days


def _build_recent_tasks(
    events: pd.DataFrame,
    activity: pd.DataFrame,
    now: pd.Timestamp,
    cfg: ProfileConfig,
) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    activity_by_user = activity.set_index("user_id")["user_activity_level"].to_dict()

    for user_id, user_events in events.groupby("user_id", sort=False):
        level = activity_by_user[user_id]
        selected = user_events[user_events["event_time"] <= now].sort_values(
            ["event_time", "action_name"], ascending=[False, True]
        )
        selected = selected.head(cfg.recent_event_top_k)
        if selected.empty:
            continue

        for rank, item in enumerate(selected.itertuples(index=False), start=1):
            rows.append(
                {
                    "user_id": user_id,
                    "action_name": item.action_name,
                    "event_time": item.event_time,
                    "rank": rank,
                    "user_activity_level": level,
                }
            )

    result = pd.DataFrame(rows)
    if result.empty:
        return _empty_recent_tasks()
    return result.sort_values(["user_id", "rank"]).reset_index(drop=True)


def _build_periodic_tasks(
    events: pd.DataFrame, now: pd.Timestamp, cfg: ProfileConfig
) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    grouped = events.groupby(["user_id", "action_name"], sort=False)
    eligible_pairs = grouped.size()
    eligible_pairs = eligible_pairs[eligible_pairs >= cfg.min_period_occurrences].index
    for user_id, action_name in eligible_pairs:
        group = grouped.get_group((user_id, action_name))
        candidate = _detect_period(group["event_time"].sort_values().tolist(), now, cfg)
        if candidate is None:
            continue
        rows.append({"user_id": user_id, "action_name": action_name, **candidate})

    if not rows:
        return _empty_periodic_tasks()
    return pd.DataFrame(rows).sort_values(
        ["user_id", "confidence", "action_name"], ascending=[True, False, True]
    ).reset_index(drop=True)


def _detect_period(
    times: list[pd.Timestamp], now: pd.Timestamp, cfg: ProfileConfig
) -> dict[str, Any] | None:
    if len(times) < cfg.min_period_occurrences:
        return None

    timestamps = sorted(pd.Timestamp(value) for value in times)
    dates = sorted({value.normalize() for value in timestamps})
    if len(dates) < cfg.min_period_occurrences:
        return None

    candidates: list[dict[str, Any]] = []
    daily_timestamps = _timestamps_in_recent_days(
        timestamps, now, cfg.daily_detection_window_days
    )
    daily_dates = _unique_dates(daily_timestamps)
    daily_stats = _date_interval_stats(daily_dates)
    if (
        daily_stats is not None
        and len(daily_dates) >= cfg.min_period_occurrences
        and daily_dates[-1] == now.normalize()
        and daily_stats["avg_interval"] <= 1.5
    ):
        candidate = _period_candidate(
            "daily",
            "every 1 day",
            daily_dates[-1] + pd.Timedelta(days=1),
            daily_stats["cv"],
            0.95,
            (
                f"最近 {cfg.daily_detection_window_days} 天内 {len(daily_dates)} "
                f"个活跃日平均间隔 {daily_stats['avg_interval']:.1f} 天"
            ),
        )
        candidate["_timestamps"] = daily_timestamps
        candidates.append(candidate)

    weekly_timestamps = _timestamps_in_recent_days(
        timestamps, now, cfg.weekly_detection_window_days
    )
    weekly_dates = _unique_dates(weekly_timestamps)
    weekly_stats = _date_interval_stats(weekly_dates)
    weekday_counts = Counter(value.weekday() for value in weekly_timestamps)
    if weekly_stats is not None and weekday_counts:
        weekday = max(weekday_counts, key=weekday_counts.get)
        concentration = weekday_counts[weekday] / len(weekly_timestamps)
        weekly_exact_timestamps = [
            value for value in weekly_timestamps if value.weekday() == weekday
        ]
        weekly_near_timestamps = [
            value
            for value in weekly_timestamps
            if _weekday_distance(value.weekday(), weekday) <= 1
        ]
        weekly_anchor_timestamps, weekly_anchor_dates, weekly_anchor_stats = (
            _best_period_dates_for_cv(
                [weekly_exact_timestamps, weekly_near_timestamps],
                min_occurrences=cfg.weekly_min_occurrences,
                min_span_days=cfg.weekly_min_span_days,
            )
        )
        if (
            weekly_anchor_stats is not None
            and concentration >= cfg.calendar_concentration
        ):
            candidate = _period_candidate(
                "weekly",
                f"weekday={weekday}",
                _next_weekday(weekly_anchor_dates[-1], weekday),
                weekly_anchor_stats["cv"],
                concentration,
                (
                    f"最近 {cfg.weekly_detection_window_days} 天内 "
                    f"{concentration:.0%} 的行为发生在星期 {weekday + 1}"
                ),
            )
            candidate["_timestamps"] = weekly_anchor_timestamps
            candidates.append(candidate)

    monthly_timestamps = _timestamps_in_recent_days(
        timestamps, now, cfg.monthly_detection_window_days
    )
    monthly_dates = _unique_dates(monthly_timestamps)
    monthly_stats = _date_interval_stats(monthly_dates)
    month_anchor, month_concentration = (
        _month_day_anchor_values([value.day for value in monthly_timestamps])
        if monthly_timestamps
        else (0, 0.0)
    )
    monthly_anchor_timestamps = [
        value for value in monthly_timestamps if abs(value.day - month_anchor) <= 2
    ]
    monthly_anchor_dates = _unique_dates(monthly_anchor_timestamps)
    monthly_anchor_stats = _date_interval_stats(monthly_anchor_dates)
    month_count = len({(value.year, value.month) for value in monthly_anchor_timestamps})
    if (
        monthly_anchor_stats is not None
        and month_count >= cfg.monthly_min_months
        and monthly_anchor_stats["span_days"] >= 45
        and month_concentration >= cfg.calendar_concentration
    ):
        candidate = _period_candidate(
            "monthly",
            f"day≈{month_anchor}",
            _next_month_day(monthly_anchor_dates[-1], month_anchor),
            monthly_anchor_stats["cv"],
            month_concentration,
            (
                f"最近 {cfg.monthly_detection_window_days} 天内 "
                f"{month_concentration:.0%} 的行为集中在每月 {month_anchor} 日前后"
            ),
        )
        candidate["_timestamps"] = monthly_anchor_timestamps
        candidates.append(candidate)

    interval_dates = (
        dates[-cfg.interval_detection_recent_occurrences :]
        if cfg.interval_detection_recent_occurrences > 0
        else []
    )
    interval_timestamps = _timestamps_for_dates(timestamps, interval_dates)
    interval_stats = _date_interval_stats(interval_dates)
    if interval_stats is not None:
        min_interval = min(interval_stats["intervals"])
        max_interval = max(interval_stats["intervals"])
        interval_ratio = max_interval / min_interval if min_interval > 0 else 999.0
        if (
            len(interval_dates) >= 4
            and len(interval_stats["intervals"]) >= 3
            and interval_stats["avg_interval"] >= 2
            and interval_stats["span_days"] >= interval_stats["avg_interval"] * 3
            and interval_stats["cv"] <= cfg.strong_period_cv
            and interval_ratio <= cfg.interval_max_min_ratio
        ):
            interval_days = max(int(round(interval_stats["avg_interval"])), 1)
            candidate = _period_candidate(
                "interval",
                f"every {interval_days} days",
                interval_dates[-1] + pd.Timedelta(days=interval_days),
                interval_stats["cv"],
                0.90,
                (
                    f"最近 {len(interval_dates)} 个活跃日相邻行为间隔约 "
                    f"{interval_days} 天，CV={interval_stats['cv']:.2f}"
                ),
            )
            candidate["_timestamps"] = interval_timestamps
            candidates.append(candidate)

    if not candidates:
        return None

    viable_candidates = [
        item for item in candidates if item["confidence"] >= cfg.min_period_confidence
    ]
    if not viable_candidates:
        return None

    monthly_candidates = [
        item for item in viable_candidates if item["period_type"] == "monthly"
    ]
    interval_candidates = [
        item
        for item in viable_candidates
        if item["period_type"] == "interval" and _interval_days_from_candidate(item) > 7.5
    ]
    selected = (
        max(monthly_candidates, key=lambda item: item["confidence"])
        if monthly_candidates
        else max(interval_candidates, key=lambda item: item["confidence"])
        if interval_candidates
        else max(viable_candidates, key=lambda item: item["confidence"])
    )
    selected = dict(selected)
    time_series = pd.Series(selected.pop("_timestamps"))
    preferred_time_window = _preferred_time_window(time_series)
    selected["preferred_time_window"] = preferred_time_window
    selected["next_expected_time"] = _apply_preferred_hour(
        selected["next_expected_time"], time_series
    )
    if selected["next_expected_time"] <= now:
        return None
    return selected


def _timestamps_in_recent_days(
    timestamps: list[pd.Timestamp], now: pd.Timestamp, window_days: int
) -> list[pd.Timestamp]:
    if window_days <= 0:
        return []
    window_start = now - pd.Timedelta(days=window_days)
    return [value for value in timestamps if window_start < value <= now]


def _unique_dates(timestamps: list[pd.Timestamp]) -> list[pd.Timestamp]:
    return sorted({value.normalize() for value in timestamps})


def _best_period_dates_for_cv(
    timestamp_options: list[list[pd.Timestamp]],
    *,
    min_occurrences: int,
    min_span_days: int,
) -> tuple[list[pd.Timestamp], list[pd.Timestamp], dict[str, Any] | None]:
    choices: list[tuple[list[pd.Timestamp], list[pd.Timestamp], dict[str, Any]]] = []
    for option in timestamp_options:
        dates = _unique_dates(option)
        stats = _date_interval_stats(dates)
        if (
            stats is not None
            and len(dates) >= min_occurrences
            and stats["span_days"] >= min_span_days
        ):
            choices.append((option, dates, stats))
    if not choices:
        return [], [], None
    return min(choices, key=lambda item: item[2]["cv"])


def _weekday_distance(value: int, target: int) -> int:
    distance = abs(value - target)
    return min(distance, 7 - distance)


def _timestamps_for_dates(
    timestamps: list[pd.Timestamp], dates: list[pd.Timestamp]
) -> list[pd.Timestamp]:
    date_set = set(dates)
    return [value for value in timestamps if value.normalize() in date_set]


def _date_interval_stats(dates: list[pd.Timestamp]) -> dict[str, Any] | None:
    if len(dates) < 2:
        return None
    intervals = [(dates[i] - dates[i - 1]).days for i in range(1, len(dates))]
    avg_interval = float(sum(intervals) / len(intervals))
    if avg_interval <= 0:
        return None
    variance = sum((value - avg_interval) ** 2 for value in intervals) / len(intervals)
    return {
        "span_days": max((dates[-1] - dates[0]).days, 0),
        "intervals": intervals,
        "avg_interval": avg_interval,
        "cv": float(sqrt(variance) / avg_interval),
    }


def _interval_days_from_candidate(candidate: dict[str, Any]) -> float:
    if candidate["period_type"] != "interval":
        return 0.0
    parts = str(candidate["period_value"]).split()
    if len(parts) < 2:
        return 0.0
    try:
        return float(parts[1])
    except ValueError:
        return 0.0


def _period_candidate(
    period_type: str,
    period_value: str,
    next_expected_time: pd.Timestamp,
    cv: float,
    concentration: float,
    evidence: str,
) -> dict[str, Any]:
    cv_score = max(0.0, min(1.0, 1.0 - cv))
    confidence = round(0.65 * cv_score + 0.35 * concentration, 6)
    return {
        "period_type": period_type,
        "period_value": period_value,
        "next_expected_time": next_expected_time,
        "confidence": confidence,
        "evidence": evidence,
    }


def _preferred_time_window(times: pd.Series) -> str:
    def bucket(hour: int) -> str:
        if 0 <= hour < 6:
            return "night"
        if 6 <= hour < 11:
            return "morning"
        if 11 <= hour < 14:
            return "noon"
        if 14 <= hour < 18:
            return "afternoon"
        return "evening"

    return str(times.dt.hour.map(bucket).value_counts().idxmax())


def _apply_preferred_hour(date_value: pd.Timestamp, times: pd.Series) -> pd.Timestamp:
    preferred_hour = int(times.dt.hour.mode().iloc[0])
    return pd.Timestamp(date_value).replace(hour=preferred_hour)


def _next_weekday(last_date: pd.Timestamp, weekday: int) -> pd.Timestamp:
    delta = (weekday - last_date.weekday()) % 7
    if delta == 0:
        delta = 7
    return last_date + pd.Timedelta(days=delta)


def _month_day_anchor(times: pd.Series) -> tuple[int, float]:
    return _month_day_anchor_values(times.dt.day.astype(int).tolist())


def _month_day_anchor_values(days: list[int]) -> tuple[int, float]:
    median_day = float(median(days))
    concentrations = {
        day: sum(abs(value - day) <= 2 for value in days) / len(days)
        for day in range(1, 32)
    }
    best_concentration = max(concentrations.values())
    candidate_days = [
        day
        for day, concentration in concentrations.items()
        if concentration == best_concentration
    ]
    best_day = min(candidate_days, key=lambda day: (abs(day - median_day), day))
    return best_day, float(best_concentration)


def _next_month_day(last_date: pd.Timestamp, target_day: int) -> pd.Timestamp:
    year = last_date.year
    month = last_date.month + 1
    if month > 12:
        year += 1
        month = 1
    days_in_month = pd.Timestamp(year=year, month=month, day=1).days_in_month
    return pd.Timestamp(year=year, month=month, day=min(target_day, days_in_month))


def _build_recent_high_freq_tasks(
    events: pd.DataFrame,
    activity: pd.DataFrame,
    periodic_tasks: pd.DataFrame,
    now: pd.Timestamp,
    cfg: ProfileConfig,
) -> pd.DataFrame:
    periodic_pairs = set()
    if not periodic_tasks.empty:
        periodic_pairs = set(
            periodic_tasks[["user_id", "action_name"]].itertuples(index=False, name=None)
        )

    activity_by_user = activity.set_index("user_id")["user_activity_level"].to_dict()
    rows: list[dict[str, Any]] = []
    for (user_id, action_name), group in events.groupby(["user_id", "action_name"]):
        if (user_id, action_name) in periodic_pairs:
            continue

        level = activity_by_user[user_id]
        count_7d = _count_between(group, now - pd.Timedelta(days=7), now)
        count_30d = _count_between(group, now - pd.Timedelta(days=30), now)
        recent_concentration = count_7d / max(count_30d, 1)
        baseline_7d = _baseline_average(group, now, recent_days=7, baseline_days=90)
        lift_7d = count_7d / max(baseline_7d, 0.5)

        selected_window = 7
        recent_count = count_7d
        baseline = baseline_7d
        lift = lift_7d

        if level == "low":
            baseline_30d = _baseline_average(group, now, recent_days=30, baseline_days=180)
            lift_30d = count_30d / max(baseline_30d, 0.5)
            if count_30d >= cfg.high_freq_recent_count_7d and lift_30d >= cfg.high_freq_lift:
                selected_window = 30
                recent_count = count_30d
                baseline = baseline_30d
                lift = lift_30d

        if recent_count < cfg.high_freq_recent_count_7d or lift < cfg.high_freq_lift:
            continue
        if recent_concentration < cfg.high_freq_recent_concentration:
            continue

        rows.append(
            {
                "user_id": user_id,
                "action_name": action_name,
                "recent_count": int(recent_count),
                "baseline_count": round(float(baseline), 6),
                "lift": round(float(lift), 6),
                "trend_score": round(log1p(recent_count) * min(lift, 10.0), 6),
                "time_window": f"{selected_window}d",
            }
        )

    if not rows:
        return _empty_high_freq_tasks()
    return pd.DataFrame(rows).sort_values(
        ["user_id", "trend_score", "recent_count"], ascending=[True, False, False]
    ).reset_index(drop=True)


def _count_between(group: pd.DataFrame, start: pd.Timestamp, end: pd.Timestamp) -> int:
    return int(((group["event_time"] > start) & (group["event_time"] <= end)).sum())


def _baseline_average(
    group: pd.DataFrame, now: pd.Timestamp, *, recent_days: int, baseline_days: int
) -> float:
    baseline_start = now - pd.Timedelta(days=baseline_days)
    baseline_end = now - pd.Timedelta(days=recent_days)
    count = _count_between(group, baseline_start, baseline_end)
    window_count = max((baseline_days - recent_days) / recent_days, 1.0)
    return count / window_count


def _build_frequent_tasks(
    events: pd.DataFrame, now: pd.Timestamp, cfg: ProfileConfig
) -> pd.DataFrame:
    user_stats = (
        events.groupby("user_id")
        .agg(
            user_total_event_count=("event_time", "size"),
            user_first_time=("event_time", "min"),
        )
        .reset_index()
    )
    task_stats = (
        events.assign(event_date=events["event_time"].dt.date)
        .groupby(["user_id", "action_name"])
        .agg(
            event_count=("event_time", "size"),
            active_days=("event_date", "nunique"),
            first_time=("event_time", "min"),
            last_time=("event_time", "max"),
        )
        .reset_index()
        .merge(user_stats, on="user_id", how="left", validate="many_to_one")
    )

    elapsed_days = (now - task_stats["user_first_time"]).dt.total_seconds() / 86400
    task_stats["observation_days"] = elapsed_days.clip(lower=1.0)
    task_stats["frequency_share"] = (
        task_stats["event_count"] / task_stats["user_total_event_count"]
    )
    task_stats["avg_monthly_count"] = (
        task_stats["event_count"] / task_stats["observation_days"] * 30
    )

    task_stats = task_stats.sort_values(
        ["user_id", "event_count", "active_days", "last_time", "action_name"],
        ascending=[True, False, False, False, True],
    )
    task_stats["rank"] = task_stats.groupby("user_id").cumcount() + 1
    task_stats = task_stats[task_stats["rank"] <= cfg.frequent_task_top_k].copy()
    task_stats["frequency_share"] = task_stats["frequency_share"].round(6)
    task_stats["observation_days"] = task_stats["observation_days"].round(6)
    task_stats["avg_monthly_count"] = task_stats["avg_monthly_count"].round(6)

    return task_stats[
        [
            "user_id",
            "action_name",
            "event_count",
            "active_days",
            "first_time",
            "last_time",
            "user_total_event_count",
            "frequency_share",
            "observation_days",
            "avg_monthly_count",
            "rank",
        ]
    ].reset_index(drop=True)


def _build_behavior_sequences(
    events: pd.DataFrame, now: pd.Timestamp, cfg: ProfileConfig
) -> pd.DataFrame:
    occurrences: list[dict[str, Any]] = []
    prefix_counts: dict[tuple[str, tuple[str, ...]], int] = {}
    global_users_by_sequence: dict[tuple[str, ...], set[str]] = {}

    for user_id, user_events in events.groupby("user_id", sort=False):
        for session in _split_sessions(user_events, cfg.session_gap_minutes):
            actions = session["action_name"].tolist()
            times = session["event_time"].tolist()
            min_prefix_len = max(cfg.sequence_min_len - 1, 1)
            max_prefix_len = max(cfg.sequence_max_len - 1, min_prefix_len)
            for start in range(len(actions)):
                for length in range(min_prefix_len, max_prefix_len + 1):
                    end = start + length
                    if end > len(actions):
                        break
                    prefix = tuple(actions[start:end])
                    key = (user_id, prefix)
                    prefix_counts[key] = prefix_counts.get(key, 0) + 1
            for start in range(len(actions)):
                for length in range(cfg.sequence_min_len, cfg.sequence_max_len + 1):
                    end = start + length
                    if end > len(actions):
                        break
                    sequence = tuple(actions[start:end])
                    occurrences.append(
                        {
                            "user_id": user_id,
                            "sequence_tuple": sequence,
                            "last_time": times[end - 1],
                        }
                    )
                    global_users_by_sequence.setdefault(sequence, set()).add(user_id)

    if not occurrences:
        return _empty_sequences()

    total_users = max(events["user_id"].nunique(), 1)
    grouped = (
        pd.DataFrame(occurrences)
        .groupby(["user_id", "sequence_tuple"])
        .agg(support_count=("last_time", "size"), last_time=("last_time", "max"))
        .reset_index()
    )

    rows: list[dict[str, Any]] = []
    for item in grouped.itertuples(index=False):
        prefix = item.sequence_tuple[:-1]
        prefix_total = prefix_counts.get((item.user_id, prefix), item.support_count)
        confidence = item.support_count / max(prefix_total, 1)
        global_user_ratio = len(global_users_by_sequence[item.sequence_tuple]) / total_users
        sequence_length = len(item.sequence_tuple)
        min_support = (
            cfg.min_pair_sequence_support
            if sequence_length == 2
            else cfg.min_long_sequence_support
        )
        min_confidence = (
            cfg.min_pair_sequence_confidence
            if sequence_length == 2
            else cfg.min_long_sequence_confidence
        )
        if item.support_count < min_support:
            continue
        if confidence < min_confidence:
            continue
        if global_user_ratio > 0.80 and confidence < 0.75:
            continue
        age_days = max(
            (pd.Timestamp(now) - item.last_time).total_seconds()
            / 86400.0,
            0.0,
        )
        length_weight = _sequence_length_weight(sequence_length)
        recency_weight = exp(-age_days / 30.0)
        sequence_score = (
            log1p(item.support_count)
            * confidence
            * length_weight
            * recency_weight
        )
        rows.append(
            {
                "user_id": item.user_id,
                "sequence": " -> ".join(item.sequence_tuple),
                "sequence_tuple": item.sequence_tuple,
                "sequence_length": sequence_length,
                "support_count": int(item.support_count),
                "last_time": item.last_time,
                "transition_confidence": round(float(confidence), 6),
                "sequence_score": round(float(sequence_score), 6),
                "next_action_candidate": item.sequence_tuple[-1],
            }
        )

    if not rows:
        return _empty_sequences()
    result = pd.DataFrame(rows)
    result = _filter_subsequences(result, cfg)
    if result.empty:
        return _empty_sequences()
    result = result.sort_values(
        ["user_id", "sequence_score", "support_count", "transition_confidence", "last_time"],
        ascending=[True, False, False, False, False],
    )
    result["rank"] = result.groupby("user_id").cumcount() + 1
    return (
        result[result["rank"] <= cfg.sequence_top_k]
        .drop(columns=["sequence_tuple", "rank"])
        .reset_index(drop=True)
    )


def _sequence_length_weight(sequence_length: int) -> float:
    if sequence_length == 2:
        return 1.0
    if sequence_length == 3:
        return 1.2
    return 1.3


def _filter_subsequences(sequences: pd.DataFrame, cfg: ProfileConfig) -> pd.DataFrame:
    keep_indexes: set[int] = set(sequences.index)
    for user_id, user_rows in sequences.groupby("user_id", sort=False):
        records = list(user_rows.itertuples())
        for short in records:
            short_tuple = short.sequence_tuple
            for long in records:
                long_tuple = long.sequence_tuple
                if len(long_tuple) <= len(short_tuple):
                    continue
                if not _is_contiguous_subsequence(short_tuple, long_tuple):
                    continue
                if short.support_count >= long.support_count + cfg.subsequence_support_margin:
                    continue
                keep_indexes.discard(short.Index)
                break
    return sequences.loc[sorted(keep_indexes)].copy()


def _is_contiguous_subsequence(short: tuple[str, ...], long: tuple[str, ...]) -> bool:
    if len(short) >= len(long):
        return False
    limit = len(long) - len(short) + 1
    return any(long[start : start + len(short)] == short for start in range(limit))


def _split_sessions(user_events: pd.DataFrame, gap_minutes: int) -> list[pd.DataFrame]:
    sorted_events = user_events.sort_values("event_time").reset_index(drop=True)
    gaps = sorted_events["event_time"].diff() > pd.Timedelta(minutes=gap_minutes)
    session_id = gaps.cumsum()
    return [session for _, session in sorted_events.groupby(session_id) if len(session) >= 2]


def _empty_recent_tasks() -> pd.DataFrame:
    return pd.DataFrame(
        columns=[
            "user_id",
            "action_name",
            "event_time",
            "rank",
            "user_activity_level",
        ]
    )


def _empty_periodic_tasks() -> pd.DataFrame:
    return pd.DataFrame(
        columns=[
            "user_id",
            "action_name",
            "period_type",
            "period_value",
            "preferred_time_window",
            "next_expected_time",
            "confidence",
            "evidence",
        ]
    )


def _empty_high_freq_tasks() -> pd.DataFrame:
    return pd.DataFrame(
        columns=[
            "user_id",
            "action_name",
            "recent_count",
            "baseline_count",
            "lift",
            "trend_score",
            "time_window",
        ]
    )


def _empty_sequences() -> pd.DataFrame:
    return pd.DataFrame(
        columns=[
            "user_id",
            "sequence",
            "sequence_length",
            "support_count",
            "last_time",
            "transition_confidence",
            "sequence_score",
            "next_action_candidate",
        ]
    )
